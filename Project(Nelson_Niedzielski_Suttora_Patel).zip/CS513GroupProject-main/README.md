CS 513 Final Project
Julia Nelson, Taylor Niedzielski, Sonia Patel, and Noah Suttora

Data source: https://www.kaggle.com/sujithsherigar/startup-success-rate-analysis?select=CAX_Startup_Data.csv
